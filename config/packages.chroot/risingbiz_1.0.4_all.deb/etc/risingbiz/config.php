<?php
declare(strict_types=1);

// Ruta a la base de datos de RisingBiz.
// No editar salvo que sepas lo que hacés: mover esto requiere migrar
// también el archivo .sqlite existente en /var/lib/risingbiz/.
define('RISINGBIZ_DB_PATH', '/var/lib/risingbiz/database.sqlite');
